// manager.js: Render and manage admin leave summary
