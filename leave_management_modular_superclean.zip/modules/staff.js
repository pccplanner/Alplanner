// staff.js: Handle staff data and leave request submission
