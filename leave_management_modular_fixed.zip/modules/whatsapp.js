// whatsapp.js: Generate WhatsApp messages for staff
